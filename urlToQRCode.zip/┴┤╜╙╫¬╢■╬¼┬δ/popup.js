document.addEventListener('DOMContentLoaded', function() {
  // 获取DOM元素
  const qrName = document.getElementById('qrName');
  const qrUrl = document.getElementById('qrUrl');
  const generateBtn = document.getElementById('generateQR');
  const qrCodeDiv = document.getElementById('qrCode');
  const historyList = document.getElementById('history');
  const clearHistoryBtn = document.getElementById('clearHistory');

  let history = [];

  // 从存储中加载历史记录
  chrome.storage.sync.get(['qrHistory'], function(result) {
    if (result.qrHistory) {
      history = result.qrHistory;
      renderHistory();
    }
  });

  // 获取当前标签页URL并生成二维码
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    const currentUrl = tabs[0].url;
    qrUrl.value = currentUrl;
    generateQRCode(currentUrl);
  });

  // 生成二维码按钮点击事件
  generateBtn.addEventListener('click', function() {
    const name = qrName.value || '未命名';
    const url = qrUrl.value;

    if (url) {
      generateQRCode(url);
      addToHistory(name, url);
    }
  });

  // 清除历史记录按钮点击事件
  clearHistoryBtn.addEventListener('click', function() {
    history = [];
    chrome.storage.sync.set({qrHistory: history});
    renderHistory();
  });

  // 生成二维码函数
  function generateQRCode(url) {
    qrCodeDiv.innerHTML = '';
    new QRCode(qrCodeDiv, {
      text: url,
      width: 250,
      height: 250
    });
  }

  // 添加到历史记录函数
  function addToHistory(name, url) {
    const item = {name, url, pinned: false};
    history.unshift(item);
    chrome.storage.sync.set({qrHistory: history});
    renderHistory();
  }

  // 渲染历史记录函数
  function renderHistory() {
    historyList.innerHTML = '';
    const sortedHistory = history.sort((a, b) => b.pinned - a.pinned);
    
    sortedHistory.forEach((item, index) => {
      const li = document.createElement('li');
      
      // 创建名称元素
      const nameSpan = document.createElement('span');
      nameSpan.textContent = item.name;
      nameSpan.className = 'history-name';
      li.appendChild(nameSpan);
      
      // 创建URL元素
      const urlSpan = document.createElement('span');
      urlSpan.textContent = item.url;
      urlSpan.className = 'history-url';
      li.appendChild(urlSpan);
      
      // 创建置顶按钮
      const pinBtn = document.createElement('button');
      pinBtn.textContent = item.pinned ? '📌' : '📍';
      pinBtn.className = 'pin-btn';
      pinBtn.addEventListener('click', () => togglePin(index));
      
      // 创建删除按钮
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = '🗑️';
      deleteBtn.className = 'delete-btn';
      deleteBtn.addEventListener('click', () => deleteHistoryItem(index));
      
      li.appendChild(pinBtn);
      li.appendChild(deleteBtn);
      historyList.appendChild(li);
    });
  }

  // 切换置顶状态函数
  function togglePin(index) {
    history[index].pinned = !history[index].pinned;
    chrome.storage.sync.set({qrHistory: history});
    renderHistory();
  }

  // 删除历史记录项函数
  function deleteHistoryItem(index) {
    history.splice(index, 1);
    chrome.storage.sync.set({qrHistory: history});
    renderHistory();
  }
});